@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0USB_Security_GUI.ps1"
if errorlevel 1 (
  echo.
  echo GUI could not start. Photograph this window to get help.
  pause
)
