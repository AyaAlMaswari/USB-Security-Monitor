﻿# USB Security Monitor - Windows PowerShell 5.1 / Windows Forms
# Works with the ESP32 firmware already uploaded: TRUSTED / ALERT / OFF at 115200 baud.
# This is a detection/alert demonstration; it does not block USB devices or scan malware.

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# Background scanner: WMI/COM work is off the WinForms UI thread.
# This way even a slow Windows device query cannot freeze the buttons.
Add-Type -AssemblyName System.Management
$engineSource = @'
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.IO.Ports;
using System.Management;
using System.Threading;

public sealed class UsbUiEvent {
    public string Kind = "";
    public string State = "";
    public string Name = "";
    public string Id = "";
    public string Detail = "";
}

public sealed class UsbBackgroundScanner {
    private readonly object sync = new object();
    private readonly ConcurrentQueue<UsbUiEvent> output = new ConcurrentQueue<UsbUiEvent>();
    private Thread thread;
    private volatile bool stopped;
    private string portName;
    private HashSet<string> trusted;

    public void Start(string port, string[] trustedIds) {
        lock(sync) {
            if (thread != null && thread.IsAlive)
                throw new InvalidOperationException("Wait until the previous monitor has stopped.");
            portName = port;
            trusted = new HashSet<string>(trustedIds, StringComparer.OrdinalIgnoreCase);
            stopped = false;
            UsbUiEvent discarded;
            while (output.TryDequeue(out discarded)) { }
            thread = new Thread(Run);
            thread.Name = "USB Device Scanner";
            thread.IsBackground = true;
            thread.Start();
        }
    }

    public void Stop() { stopped = true; }
    public bool TryDequeue(out UsbUiEvent item) { return output.TryDequeue(out item); }

    private void Publish(string kind, string state = "", string name = "", string id = "", string detail = "") {
        output.Enqueue(new UsbUiEvent { Kind = kind, State = state, Name = name, Id = id, Detail = detail });
    }

    private bool Pause(int milliseconds) {
        int elapsed = 0;
        while (elapsed < milliseconds && !stopped) {
            int part = Math.Min(100, milliseconds - elapsed);
            Thread.Sleep(part);
            elapsed += part;
        }
        return !stopped;
    }

    private static Dictionary<string, string> ScanPresentDrives() {
        var devices = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        // ConfigManagerErrorCode 0 means the PnP device is working/connected.
        const string query = "SELECT PNPDeviceID, Name, ConfigManagerErrorCode FROM Win32_PnPEntity WHERE Name = 'USB Mass Storage Device'";
        using (var searcher = new ManagementObjectSearcher(query)) {
            using (var found = searcher.Get()) {
                foreach (ManagementObject device in found) {
                    using (device) {
                        string id = Convert.ToString(device["PNPDeviceID"]);
                        string name = Convert.ToString(device["Name"]);
                        object code = device["ConfigManagerErrorCode"];
                        if (!string.IsNullOrEmpty(id) &&
                            id.StartsWith(@"USB\VID_", StringComparison.OrdinalIgnoreCase) &&
                            code != null && Convert.ToInt32(code) == 0) {
                            devices[id] = string.IsNullOrEmpty(name) ? "USB Mass Storage Device" : name;
                        }
                    }
                }
            }
        }
        return devices;
    }

    private string ChooseCommand(Dictionary<string, string> current) {
        bool hasTrusted = false;
        foreach (string id in current.Keys) {
            if (!trusted.Contains(id)) return "ALERT";
            hasTrusted = true;
        }
        return hasTrusted ? "TRUSTED" : "OFF";
    }

    private void Run() {
        SerialPort serial = null;
        try {
            Publish("CONNECTING");
            serial = new SerialPort(portName, 115200);
            serial.NewLine = "\n";
            serial.WriteTimeout = 1500;
            serial.Open();
            if (!Pause(2100)) return; // Serial port opening can reset ESP32.
            serial.WriteLine("OFF");
            var known = ScanPresentDrives();
            Publish("READY", "", "", "", portName);

            while (!stopped) {
                var current = ScanPresentDrives();
                bool changed = false;
                foreach (var entry in current) {
                    if (known.ContainsKey(entry.Key)) continue;
                    bool allowed = trusted.Contains(entry.Key);
                    Publish("DEVICE", allowed ? "REGISTERED" : "UNREGISTERED", entry.Value, entry.Key);
                    if (!allowed) {
                        try { Console.Beep(1000, 500); } catch { }
                    }
                    changed = true;
                }
                foreach (string oldId in known.Keys) {
                    if (!current.ContainsKey(oldId)) { changed = true; break; }
                }
                if (changed) {
                    string command = ChooseCommand(current);
                    serial.WriteLine(command);
                    Publish("STATE", command);
                }
                known = current;
                if (!Pause(1400)) break;
            }
        } catch (Exception ex) {
            if (!stopped) Publish("ERROR", "", "", "", ex.Message);
        } finally {
            if (serial != null) {
                try { if (serial.IsOpen) serial.WriteLine("OFF"); } catch { }
                try { if (serial.IsOpen) serial.Close(); } catch { }
                try { serial.Dispose(); } catch { }
            }
            Publish("STOPPED");
        }
    }
}
'@
Add-Type -TypeDefinition $engineSource -Language CSharp -ReferencedAssemblies @('System.Management.dll', 'System.dll')
$script:engine = [UsbBackgroundScanner]::new()


$script:serial = $null
$script:running = $false
$script:knownIds = @()
$script:trustedIds = @()
$script:allowedCount = 0
$script:alertCount = 0

$desktopPath = [Environment]::GetFolderPath('Desktop')
$trustCandidates = @(
    (Join-Path $desktopPath 'TrustedUSB.txt'),
    (Join-Path $env:USERPROFILE 'Desktop\TrustedUSB.txt'),
    (Join-Path $PSScriptRoot 'TrustedUSB.txt')
)
$script:trustedPath = @($trustCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1)
if ($script:trustedPath.Count -gt 0) {
    $script:trustedPath = $script:trustedPath[0]
    $script:logPath = Join-Path (Split-Path $script:trustedPath -Parent) 'USB_Security_Log.txt'
} else {
    $script:trustedPath = Join-Path $desktopPath 'TrustedUSB.txt'
    $script:logPath = Join-Path $desktopPath 'USB_Security_Log.txt'
}

function Color([int]$r, [int]$g, [int]$b) {
    return [System.Drawing.Color]::FromArgb($r, $g, $b)
}

$bg = Color 15 23 42
$panelBg = Color 30 41 59
$white = Color 241 245 249
$muted = Color 148 163 184
$green = Color 74 222 128
$red = Color 251 113 133
$amber = Color 251 191 36
$cyan = Color 56 189 248

$form = New-Object System.Windows.Forms.Form
$form.Text = 'USB Security Center | ESP32'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = [System.Drawing.Size]::new(980, 685)
$form.BackColor = $bg
$form.ForeColor = $white
$form.Font = [System.Drawing.Font]::new('Segoe UI', 10)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false

function New-Label {
    param(
        [string]$Text, [int]$X, [int]$Y, [int]$W, [int]$H,
        [float]$Size = 10, [System.Drawing.Color]$ForeColor = $white,
        [bool]$Bold = $false
    )
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text
    $l.Location = [System.Drawing.Point]::new($X, $Y)
    $l.Size = [System.Drawing.Size]::new($W, $H)
    $l.ForeColor = $ForeColor
    $l.BackColor = [System.Drawing.Color]::Transparent
    $l.TextAlign = 'MiddleRight'
    $l.RightToLeft = 'Yes'
    if ($Bold) { $l.Font = [System.Drawing.Font]::new('Segoe UI', $Size, [System.Drawing.FontStyle]::Bold) }
    else { $l.Font = [System.Drawing.Font]::new('Segoe UI', $Size) }
    $form.Controls.Add($l)
    $l.BringToFront()
    return $l
}

function New-Panel([int]$x,[int]$y,[int]$w,[int]$h) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Location = [System.Drawing.Point]::new($x,$y)
    $p.Size = [System.Drawing.Size]::new($w,$h)
    $p.BackColor = $panelBg
    $form.Controls.Add($p)
    return $p
}

function New-Button {
    param([string]$Text,[int]$X,[int]$Y,[int]$W,[int]$H,[System.Drawing.Color]$Back)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = [System.Drawing.Point]::new($X,$Y)
    $b.Size = [System.Drawing.Size]::new($W,$H)
    $b.BackColor = $Back
    $b.ForeColor = $white
    $b.FlatStyle = 'Flat'
    $b.FlatAppearance.BorderSize = 0
    $b.Font = [System.Drawing.Font]::new('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    $b.Cursor = 'Hand'
    $form.Controls.Add($b)
    $b.BringToFront()
    return $b
}

$header = New-Panel 16 16 948 94
$header.BackColor = Color 22 33 54
$title = New-Label 'USB SECURITY CENTER  |  مركز مراقبة USB' 38 27 900 42 20 $white $true
$subtitle = New-Label 'كشف وتسجيل أجهزة التخزين غير المسجلة - تنبيه فقط، لا يمنع الوصول ولا يفحص الفيروسات' 38 73 900 24 10 $muted

$mainCard = New-Panel 16 124 948 115
$cardTitle = New-Label 'حالة النظام' 730 130 208 28 11 $muted $true
$script:statusLabel = New-Label 'متوقف - اضغطي بدء المراقبة' 400 161 535 53 17 $amber $true
$deviceHint = New-Label 'الأجهزة الموجودة قبل بدء المراقبة: افصليها بأمان وأعيدي توصيلها للاختبار.' 32 194 580 27 9 $muted

$script:countTrusted = New-Label '0' 580 254 110 44 23 $green $true
$countTrustedText = New-Label 'توصيلات مسجلة' 570 301 150 26 10 $muted
$script:countUnknown = New-Label '0' 798 254 110 44 23 $red $true
$countUnknownText = New-Label 'توصيلات غير مسجلة' 765 301 175 26 10 $muted

$portTitle = New-Label 'منفذ ESP32' 322 258 210 25 10 $muted
$portBox = New-Object System.Windows.Forms.TextBox
$portBox.Location = [System.Drawing.Point]::new(382, 288)
$portBox.Size = [System.Drawing.Size]::new(135,32)
$portBox.Text = 'COM10'
$portBox.Font = [System.Drawing.Font]::new('Consolas', 13)
$portBox.BackColor = Color 51 65 85
$portBox.ForeColor = $white
$portBox.TextAlign = 'Center'
$portBox.BorderStyle = 'FixedSingle'
$form.Controls.Add($portBox)

$script:trustInfo = New-Label 'قائمة الأجهزة الموثوقة: جاري الفحص' 16 337 947 27 10 $muted

$btnStart = New-Button 'بدء المراقبة' 781 375 182 43 (Color 22 163 74)
$btnStop = New-Button 'إيقاف' 637 375 132 43 (Color 71 85 105)
$btnStop.Enabled = $false
$btnLog = New-Button 'فتح سجل الأحداث' 432 375 193 43 (Color 30 64 175)
$btnTrust = New-Button 'عرض القائمة الموثوقة' 197 375 224 43 (Color 51 65 85)

$eventsTitle = New-Label 'سجل الأحداث المباشر' 604 431 354 36 13 $white $true
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = [System.Drawing.Point]::new(16,471)
$grid.Size = [System.Drawing.Size]::new(948,175)
$grid.BackgroundColor = $panelBg
$grid.BorderStyle = 'None'
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.AllowUserToResizeRows = $false
$grid.MultiSelect = $false
$grid.ReadOnly = $true
$grid.RowHeadersVisible = $false
$grid.SelectionMode = 'FullRowSelect'
$grid.AutoSizeColumnsMode = 'Fill'
$grid.EnableHeadersVisualStyles = $false
$grid.ColumnHeadersHeight = 33
$grid.ColumnHeadersDefaultCellStyle.BackColor = Color 51 65 85
$grid.ColumnHeadersDefaultCellStyle.ForeColor = $white
$grid.DefaultCellStyle.BackColor = $panelBg
$grid.DefaultCellStyle.ForeColor = $white
$grid.DefaultCellStyle.SelectionBackColor = Color 51 65 85
$grid.DefaultCellStyle.SelectionForeColor = $white
$grid.GridColor = Color 51 65 85
[void]$grid.Columns.Add('ts', 'الوقت')
[void]$grid.Columns.Add('state', 'الحالة')
[void]$grid.Columns.Add('name', 'نوع الجهاز')
[void]$grid.Columns.Add('id', 'USB Instance ID')
$grid.Columns['ts'].FillWeight = 19
$grid.Columns['state'].FillWeight = 16
$grid.Columns['name'].FillWeight = 22
$grid.Columns['id'].FillWeight = 43
$form.Controls.Add($grid)
$footer = New-Label 'تنبيه تجريبي: لا يتم حظر الفلاشات أو فحص البرمجيات الخبيثة. للإيقاف اضغطي زر إيقاف.' 16 651 944 26 9 $muted

$script:timer = New-Object System.Windows.Forms.Timer
$script:timer.Interval = 250

# All slow USB queries and serial writes are handled by UsbBackgroundScanner.

function Add-Event([string]$state, [string]$name, [string]$id) {
    $time = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $idx = $grid.Rows.Add($time, $state, $name, $id)
    if ($state -eq 'REGISTERED') {
        $grid.Rows[$idx].DefaultCellStyle.ForeColor = $green
    } else {
        $grid.Rows[$idx].DefaultCellStyle.ForeColor = $red
    }
    $grid.FirstDisplayedScrollingRowIndex = $idx
    "$time | $state | $name | $id" | Add-Content -LiteralPath $script:logPath -Encoding UTF8
}

function Stop-Monitor {
    if (-not $script:running) { return }
    $script:engine.Stop()
    $script:statusLabel.Text = 'جاري إيقاف المراقبة وتحرير المنفذ...'
    $script:statusLabel.ForeColor = $amber
    $btnStop.Enabled = $false
}

function Start-Monitor {
    if ($script:running) { return }
    if (-not (Test-Path -LiteralPath $script:trustedPath)) {
        [System.Windows.Forms.MessageBox]::Show('لم أجد TrustedUSB.txt على سطح المكتب.', 'قائمة الأجهزة غير موجودة') | Out-Null
        return
    }
    $port = $portBox.Text.Trim().ToUpperInvariant()
    if ($port -notmatch '^COM[0-9]{1,3}$') {
        [System.Windows.Forms.MessageBox]::Show('اكتبي منفذ اللوحة مثل COM10.', 'منفذ غير صحيح') | Out-Null
        return
    }
    try {
        $script:trustedIds = @(Get-Content -LiteralPath $script:trustedPath -ErrorAction Stop |
            ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
        if ($script:trustedIds.Count -eq 0) {
            throw 'TrustedUSB.txt is empty.'
        }
        $script:engine.Start($port, [string[]]$script:trustedIds)
        $script:running = $true
        $btnStart.Enabled = $false
        $btnStop.Enabled = $true
        $portBox.Enabled = $false
        $script:statusLabel.Text = 'جاري الاتصال باللوحة... يمكن إيقافه في أي لحظة'
        $script:statusLabel.ForeColor = $amber
        $script:trustInfo.Text = "قائمة الموثوقة: $($script:trustedIds.Count)  |  السجل: USB_Security_Log.txt"
        $script:timer.Start()
    } catch {
        [System.Windows.Forms.MessageBox]::Show("تعذر بدء المراقبة: $($_.Exception.Message)", 'خطأ في البدء') | Out-Null
    }
}

function Show-TextWindow([string]$windowTitle, [string]$filePath) {
    $viewer = New-Object System.Windows.Forms.Form
    $viewer.Text = $windowTitle
    $viewer.StartPosition = 'CenterParent'
    $viewer.ClientSize = [System.Drawing.Size]::new(820, 460)
    $viewer.BackColor = $panelBg
    $viewText = New-Object System.Windows.Forms.TextBox
    $viewText.Multiline = $true
    $viewText.ReadOnly = $true
    $viewText.ScrollBars = 'Both'
    $viewText.WordWrap = $false
    $viewText.Font = [System.Drawing.Font]::new('Consolas', 10)
    $viewText.Dock = 'Fill'
    $viewText.BackColor = $bg
    $viewText.ForeColor = $white
    $loadContents = {
        try {
            if (Test-Path -LiteralPath $filePath) {
                $viewText.Lines = @(Get-Content -LiteralPath $filePath -Encoding UTF8 -ErrorAction Stop)
            } else {
                $viewText.Text = 'لم يتم إنشاء هذا الملف بعد.'
            }
        } catch {
            $viewText.Text = "تعذر قراءة الملف: $($_.Exception.Message)"
        }
    }.GetNewClosure()
    $bar = New-Object System.Windows.Forms.Panel
    $bar.Dock = 'Bottom'
    $bar.Height = 48
    $bar.BackColor = $panelBg
    $refresh = New-Object System.Windows.Forms.Button
    $refresh.Text = 'تحديث العرض'
    $refresh.Location = [System.Drawing.Point]::new(650, 8)
    $refresh.Size = [System.Drawing.Size]::new(148, 31)
    $refresh.BackColor = Color 30 64 175
    $refresh.ForeColor = $white
    $refresh.FlatStyle = 'Flat'
    $refresh.Add_Click($loadContents)
    $bar.Controls.Add($refresh)
    $viewer.Controls.Add($viewText)
    $viewer.Controls.Add($bar)
    & $loadContents
    $viewer.Show($form)
    $viewer.BringToFront()
}

$script:timer.Add_Tick({
    [UsbUiEvent]$evt = $null
    $processed = 0
    while ($processed -lt 80 -and $script:engine.TryDequeue([ref]$evt)) {
        $processed++
        switch ($evt.Kind) {
            'CONNECTING' {
                $script:statusLabel.Text = 'جاري تهيئة الاتصال...'
                $script:statusLabel.ForeColor = $amber
            }
            'READY' {
                $script:statusLabel.Text = 'المراقبة تعمل - بانتظار توصيل فلاشة جديدة'
                $script:statusLabel.ForeColor = $cyan
            }
            'DEVICE' {
                if ($evt.State -eq 'REGISTERED') {
                    $script:allowedCount++
                    $script:countTrusted.Text = [string]$script:allowedCount
                } else {
                    $script:alertCount++
                    $script:countUnknown.Text = [string]$script:alertCount
                }
                Add-Event $evt.State $evt.Name $evt.Id
            }
            'STATE' {
                switch ($evt.State) {
                    'TRUSTED' {
                        $script:statusLabel.Text = 'فلاشة مسجلة - اللمبة الخضراء'
                        $script:statusLabel.ForeColor = $green
                    }
                    'ALERT' {
                        $script:statusLabel.Text = 'تنبيه: فلاشة غير مسجلة - اللمبة الحمراء'
                        $script:statusLabel.ForeColor = $red
                    }
                    'OFF' {
                        $script:statusLabel.Text = 'لا توجد فلاشة موصولة - بانتظار جهاز جديد'
                        $script:statusLabel.ForeColor = $cyan
                    }
                }
            }
            'ERROR' {
                $script:statusLabel.Text = 'خطأ: ' + $evt.Detail
                $script:statusLabel.ForeColor = $red
                [System.Windows.Forms.MessageBox]::Show(
                    "تعذرت المراقبة: $($evt.Detail)`n`nأغلقي Serial Monitor وأي برنامج PowerShell يستخدم COM10.",
                    'مشكلة في الاتصال') | Out-Null
            }
            'STOPPED' {
                $script:running = $false
                $btnStart.Enabled = $true
                $btnStop.Enabled = $false
                $portBox.Enabled = $true
                if ($script:statusLabel.Text -notlike 'خطأ:*') {
                    $script:statusLabel.Text = 'متوقف - تم تحرير المنفذ'
                    $script:statusLabel.ForeColor = $amber
                }
                $script:timer.Stop()
            }
        }
        $evt = $null
    }
})

$btnStart.Add_Click({ Start-Monitor })
$btnStop.Add_Click({ Stop-Monitor })
$btnLog.Add_Click({ Show-TextWindow 'USB Security Log' $script:logPath })
$btnTrust.Add_Click({ Show-TextWindow 'Trusted USB Devices' $script:trustedPath })
$form.Add_FormClosing({ $script:engine.Stop(); $script:timer.Stop() })

if (Test-Path -LiteralPath $script:trustedPath) {
    $script:trustInfo.Text = 'تم العثور على TrustedUSB.txt - جاهز للبدء'
} else {
    $script:trustInfo.Text = 'لم يتم العثور على TrustedUSB.txt على سطح المكتب'
    $script:trustInfo.ForeColor = $red
}

[System.Windows.Forms.Application]::Run($form)
